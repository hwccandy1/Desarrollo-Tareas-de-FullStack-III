package com.usuarioservice.usuarioservice.service;

import com.usuarioservice.usuarioservice.model.Usuario;

import java.util.List;
import java.util.Optional;

public interface UsuarioService {

    List<Usuario> listarTodos();

    Optional<Usuario> obtenerPorId(Long id);

    Usuario crearUsuario(Usuario usuario);

    void eliminarUsuario(Long id);
}
