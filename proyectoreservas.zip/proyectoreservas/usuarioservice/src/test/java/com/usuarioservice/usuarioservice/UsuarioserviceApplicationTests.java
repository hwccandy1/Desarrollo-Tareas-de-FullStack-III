package com.usuarioservice.usuarioservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsuarioserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
